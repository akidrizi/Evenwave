(() => {
  if (window.__earBalanceLoaded) return;
  window.__earBalanceLoaded = true;

  // --- tuning -------------------------------------------------------------
  const TICK_MS = 200;        // how often we measure
  const CONFIRM_TICKS = 15;   // ~3s of consistent evidence before acting
  const SILENT_RATIO = 0.06;  // quiet/loud amplitude ratio that counts as "dead"
  const NOISE_FLOOR = 0.004;  // below this, treat as silence and measure nothing
  const EMA = 0.25;           // smoothing on the per-channel level
  const RAMP = 0.06;          // gain ramp, in seconds, to avoid clicks

  // --- state --------------------------------------------------------------
  let cfg = { enabled: true, mode: 'auto' }; // auto | mono | left | right | off
  let ctx = null;
  let chain = null;
  let media = null;
  let emaL = 0, emaR = 0, hits = 0, clears = 0;
  const bufL = new Float32Array(2048);
  const bufR = new Float32Array(2048);

  const status = {
    attached: false,
    playing: false,
    detected: null,   // null | 'left' | 'right'  (side that still has sound)
    applied: 'off',
    level: { l: 0, r: 0 },
    error: null
  };

  chrome.storage.sync.get(cfg, (v) => { cfg = v; applyRouting(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    for (const [k, c] of Object.entries(changes)) cfg[k] = c.newValue;
    applyRouting();
  });

  // --- graph --------------------------------------------------------------
  // src -> splitter -> [analysers]
  //                 -> 4 gain nodes (2x2 matrix) -> merger -> destination
  function attach(el) {
    if (!el || el === media) return;
    try {
      ctx = ctx || new AudioContext();
      if (media && media.__ebSrc) media.__ebSrc.disconnect();

      const src = el.__ebSrc || ctx.createMediaElementSource(el);
      el.__ebSrc = src;

      const splitter = ctx.createChannelSplitter(2);
      const merger = ctx.createChannelMerger(2);
      const aL = ctx.createAnalyser();
      const aR = ctx.createAnalyser();
      aL.fftSize = 2048;
      aR.fftSize = 2048;

      const g = {
        ll: ctx.createGain(), // left in  -> left out
        lr: ctx.createGain(), // left in  -> right out
        rl: ctx.createGain(), // right in -> left out
        rr: ctx.createGain()  // right in -> right out
      };

      src.connect(splitter);
      splitter.connect(aL, 0);
      splitter.connect(aR, 1);
      splitter.connect(g.ll, 0);
      splitter.connect(g.lr, 0);
      splitter.connect(g.rl, 1);
      splitter.connect(g.rr, 1);
      g.ll.connect(merger, 0, 0);
      g.rl.connect(merger, 0, 0);
      g.lr.connect(merger, 0, 1);
      g.rr.connect(merger, 0, 1);
      merger.connect(ctx.destination);

      chain = { splitter, merger, aL, aR, g };
      media = el;
      emaL = emaR = hits = clears = 0;
      status.attached = true;
      status.detected = null;
      status.error = null;
      applyRouting();
    } catch (e) {
      status.attached = false;
      status.error = (e && e.message) || String(e);
    }
  }

  function setGain(node, value) {
    node.gain.setTargetAtTime(value, ctx.currentTime, RAMP);
  }

  function applyRouting() {
    if (!chain) return;
    const mode = cfg.enabled ? cfg.mode : 'off';
    let m; // [ll, lr, rl, rr]

    if (mode === 'mono') m = [0.7, 0.7, 0.7, 0.7];
    else if (mode === 'left') m = [1, 1, 0, 0];
    else if (mode === 'right') m = [0, 0, 1, 1];
    else if (mode === 'auto' && status.detected === 'left') m = [1, 1, 0, 0];
    else if (mode === 'auto' && status.detected === 'right') m = [0, 0, 1, 1];
    else m = [1, 0, 0, 1]; // untouched stereo

    setGain(chain.g.ll, m[0]);
    setGain(chain.g.lr, m[1]);
    setGain(chain.g.rl, m[2]);
    setGain(chain.g.rr, m[3]);
    status.applied = m[1] || m[2] ? (mode === 'mono' ? 'mono' : 'duplicated') : 'off';
  }

  // --- measurement --------------------------------------------------------
  function rms(analyser, buf) {
    analyser.getFloatTimeDomainData(buf);
    let sum = 0;
    for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
    return Math.sqrt(sum / buf.length);
  }

  function tick() {
    status.playing = !!(media && !media.paused && !media.ended);
    if (!chain || !status.playing || media.muted) return;

    emaL += (rms(chain.aL, bufL) - emaL) * EMA;
    emaR += (rms(chain.aR, bufR) - emaR) * EMA;
    status.level = { l: emaL, r: emaR };

    const loud = Math.max(emaL, emaR);
    const quiet = Math.min(emaL, emaR);
    if (loud < NOISE_FLOOR) return; // silent passage, no evidence either way

    if (quiet / loud < SILENT_RATIO) { hits++; clears = 0; }
    else { clears++; hits = 0; }

    if (hits >= CONFIRM_TICKS) {
      const side = emaL > emaR ? 'left' : 'right';
      if (status.detected !== side) { status.detected = side; applyRouting(); }
    } else if (clears >= CONFIRM_TICKS && status.detected) {
      status.detected = null;
      applyRouting();
    }
  }

  // --- lifecycle ----------------------------------------------------------
  const resume = () => { if (ctx && ctx.state === 'suspended') ctx.resume(); };
  document.addEventListener('pointerdown', resume, true);
  document.addEventListener('keydown', resume, true);
  document.addEventListener('play', resume, true);

  setInterval(() => {
    const el = document.querySelector('video');
    if (el && el !== media) attach(el);           // survives SPA navigation
  }, 1000);

  setInterval(tick, TICK_MS);

  chrome.runtime.onMessage.addListener((msg, sender, send) => {
    if (msg && msg.type === 'eb:status') {
      send({ ...status, cfg, ctxState: ctx ? ctx.state : 'none' });
    }
    return true;
  });
})();
